import urllib.request
import libcalamares

def has_internet():
    try:
        urllib.request.urlopen("http://connectivitycheck.gstatic.com/generate_204", timeout=5)
        return True
    except:
        return False

def run():
    if not has_internet():
        # Clear any install operations netinstall may have queued
        # to prevent packages step from failing
        existing = libcalamares.globalstorage.value("packageOperations") or []
        cleaned = [op for op in existing if not op.get("install") and not op.get("try_install")]
        libcalamares.globalstorage.insert("packageOperations", cleaned)

    return None
