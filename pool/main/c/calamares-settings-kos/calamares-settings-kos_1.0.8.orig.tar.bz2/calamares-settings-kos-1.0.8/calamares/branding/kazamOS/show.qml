/* === This file is part of Calamares - <http://github.com/calamares> ===
 *
 *   Copyright 2015, Teo Mrnjavac <teo@kde.org>
 *   Copyright 2018-2019, Jonathan Carter <jcc@debian.org>
 *   Copyright 2026, Kazam <kazam0180@proton.me>
 *
 *   Calamares is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, or (at your option) any later version.
 *
 *   Calamares is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with Calamares. If not, see <http://www.gnu.org/licenses/>.
 */

import QtQuick 2.0;
import calamares.slideshow 1.0;

Presentation
{
    id: presentation
    anchors.fill: parent

    Rectangle {
        anchors.fill: parent
        color: "#262638"
    }

    Timer {
        interval: 20000
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    Slide {
        Image {
            id: background1
            source: "slide1.png"
            width: 467; height: 280
            fillMode: Image.PreserveAspectFit
            anchors.centerIn: parent
        }

        Text {
            id: slidetext
            anchors.horizontalCenter: background1.horizontalCenter
            anchors.top: background1.bottom
            text: qsTr("The rest of the process is automated should complete in a few minutes.")
            wrapMode: Text.WordWrap
            width: 600
            horizontalAlignment: Text.AlignHCenter
            color: "white"
        }

        Text {
            id: donatetext
            anchors.horizontalCenter: background1.horizontalCenter
            anchors.top: slidetext.bottom
            anchors.topMargin: 16
            text: "Enjoying this? Consider donating!"
            color: "#d7e8f0"
        }

        Rectangle {
            id: openBtn
            anchors.horizontalCenter: background1.horizontalCenter
            anchors.top: donatetext.bottom
            anchors.topMargin: 6
            width: 180; height: 32
            radius: 4
            color: openMouse.containsMouse ? "#a15dc3" : "#784591"

            Text {
                anchors.centerIn: parent
                text: "Donate"
                color: "white"
            }

            MouseArea {
                id: openMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Qt.openUrlExternally("donatepage:")
            }
        }
    }
}
