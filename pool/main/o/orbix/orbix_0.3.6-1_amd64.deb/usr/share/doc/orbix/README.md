###### top-link

# Orbix
This is utility that automates the creation of Call of Duty ®️ (2003) and it's expansion pack, United Offensive.
It downloads and creates symlinks and copies of required files.<br>
It also gives you the option to install **iw1x-server** and **t1x-server** globally or locally.<br>
The script included installs [this fork](https://gitlab.com/kazam0180/iw1x-server) of **iw1x-server** but you can modify it to clone from your own repo.<br>
Scripts for installation of other extensions are welcome for merge requests :)

## Screenshots

![1st Screenshot of Orbix](images/1.png)
![2nd Screenshot of Orbix](images/2.png)
![3rd Screenshot of Orbix](images/3.png)
![4th Screenshot of Orbix](images/4.png)
![5th Screenshot of Orbix](images/5.png)

## Installation
The best way to install on Debian/Ubuntu based systems is to add [our apt repository](https://github.com/Wolf-Pack-Clan/kOS-packages/).</br>
Then install the `orbix` package using `apt`.

```bash
sudo apt update
sudo apt install orbix
```
</br>

Arch Linux based distros are also supported but currently there are no packages. You can download the debian packages from [apt repo](https://wolf-pack-clan.github.io/kOS-packages/pool/main/o/orbix/) and extract the binary.
Merge requests for PKGBUILD files are welcome.

### Notes
Orbix relies on timezone to set location in cfg. So, it may not work in chroot or WSL if timezone is not set.
